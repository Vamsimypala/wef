from flask import Flask, request, jsonify, render_template
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

app = Flask(__name__)

# Load the dataset
data = pd.read_csv('final_hack\d.csv')

# Prepare the data
features = data[['Recipe_Complexity', 'Ingredients', 'Chef_Experience']]
target = data['Cooking_Time']

# Split the data into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Function to predict cooking time for a new recipe
def predict_cooking_time(recipe_complexity, ingredients, chef_experience):
    # Predict the cooking time
    predicted_cooking_time = model.predict([[recipe_complexity, ingredients, chef_experience]])
    return predicted_cooking_time[0]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)
    recipe_complexity = float(data['recipe_complexity'])
    ingredients = float(data['ingredients'])
    chef_experience = float(data['chef_experience'])

    # Predict cooking time using the loaded model
    predicted_cooking_time = predict_cooking_time(recipe_complexity, ingredients, chef_experience)

    # Send the prediction back as JSON response
    response = {'predicted_cooking_time': predicted_cooking_time}
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
