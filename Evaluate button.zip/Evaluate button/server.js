// server.js
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const multer = require('multer');

app.use(bodyParser.json());

// Connect to MongoDB (replace with your MongoDB connection string)
mongoose.connect('mongodb://localhost:27017/taskApp', { useNewUrlParser: true, useUnifiedTopology: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });

const TaskSchema = new mongoose.Schema({
  title: String,
  description: String,
  uploadedFile: String
});

const Task = mongoose.model('Task', TaskSchema);

// Endpoint to upload file
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    const { title, description } = req.body;
    const task = new Task({
      title,
      description,
      uploadedFile: req.file.filename
    });
    await task.save();
    res.json({ message: 'File uploaded successfully' });
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).json({ error: 'An error occurred while uploading the file' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
